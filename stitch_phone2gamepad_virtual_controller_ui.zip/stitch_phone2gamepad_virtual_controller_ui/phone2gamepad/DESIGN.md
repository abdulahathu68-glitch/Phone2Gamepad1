---
name: Phone2Gamepad
colors:
  surface: '#121315'
  surface-dim: '#121315'
  surface-bright: '#38393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1c1e'
  surface-container: '#1f2022'
  surface-container-high: '#292a2c'
  surface-container-highest: '#343537'
  on-surface: '#e3e2e4'
  on-surface-variant: '#c2c9b3'
  inverse-surface: '#e3e2e4'
  inverse-on-surface: '#303032'
  outline: '#8c937f'
  outline-variant: '#424938'
  surface-tint: '#9dd852'
  primary: '#fcfff0'
  on-primary: '#1f3700'
  primary-container: '#b6f36a'
  on-primary-container: '#446f00'
  inverse-primary: '#406900'
  secondary: '#c3c6ce'
  on-secondary: '#2d3137'
  secondary-container: '#484c52'
  on-secondary-container: '#b8bcc3'
  tertiary: '#fffdff'
  on-tertiary: '#68000f'
  tertiary-container: '#ffd8d6'
  on-tertiary-container: '#b3373a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b8f56b'
  primary-fixed-dim: '#9dd852'
  on-primary-fixed: '#102000'
  on-primary-fixed-variant: '#2f4f00'
  secondary-fixed: '#dfe2ea'
  secondary-fixed-dim: '#c3c6ce'
  on-secondary-fixed: '#181c21'
  on-secondary-fixed-variant: '#43474d'
  tertiary-fixed: '#ffdad8'
  tertiary-fixed-dim: '#ffb3b0'
  on-tertiary-fixed: '#410006'
  on-tertiary-fixed-variant: '#8b1921'
  background: '#121315'
  on-background: '#e3e2e4'
  surface-variant: '#343537'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system delivers a professional, high-performance peripheral control utility for Android. Grounded in technical precision, engineering clarity, and distraction-free ergonomics, the visual identity references hardware companion suites (such as SteelSeries GG, PlayStation DualSense OS, and industrial telemetry displays) rather than flashy consumer gaming apps.

### Visual Aesthetic
- **Minimalist Industrial**: Matte surfaces, engineered structures, strict planar alignment, and low-contrast borders.
- **Zero Cyberpunk Noise**: Eliminates gratuitous neon glows, faux-holographic grids, and heavy chromatic gradients.
- **High Information Density**: Built for rapid visual parsing, low-latency thumb interaction, and tactile feedback clarity.
- **Hardware Integration**: The software UI recedes into the physical bezel, making the smartphone feel like a cohesive, purpose-built controller.

## Colors

The palette uses deep neutral layers punctuated by a functional lime green accent for connectivity, low-latency indicators, and verified inputs.

### Surface Architecture
- **Canvas / Root Background (`#101113`)**: Base background simulating anti-glare hardware casing.
- **Surface Secondary (`#191B1F`)**: Structural shells, inactive thumb pads, and panel containers.
- **Surface Elevated (`#22252A`)**: Floating controls, interactive modals, thumbsticks, and button caps.
- **Stroke / Boundary (`#30343A`)**: Precision dividers, calibrated dial tracks, and 1px component borders.

### Accents & Feedback
- **Calibrated Accent (`#B6F36A`)**: Used selectively for active Bluetooth handshakes, active toggles, calibration crosshairs, and thumbstick axes. Avoid broad fills; prioritize crisp line indicators and status dots.
- **Telemetry Error (`#F06464`)**: Packet loss, input disconnects, critical latency spikes, and destructive mappings.
- **Text Primary (`#F2F3F5`)**: Maximum-contrast readouts, axis values, and current profile titles.
- **Text Secondary (`#92979F`)**: Sub-labels, inactive axis ticks, input indices, and secondary technical specs.

## Typography

The typography system relies on functional differentiation:
- **Display & Headings**: `Space Grotesk` introduces clean, structured geometric details without distracting ornamentation.
- **Body & Ergonomics**: `Geist` provides neutral, readable legibility on high-density mobile screens under variable lighting conditions.
- **Telemetry & Technical Indicators**: `JetBrains Mono` handles all numerical measurements, latency readings (`ms`), deadzone tolerances (`%`), and button bind identifiers (`L1`, `R2`, `X`, `Y`). All numbers render tabularly to eliminate layout shifting during live telemetry.

## Layout & Spacing

Designed primarily for Android landscape orientation (controller mode) and compact portrait orientation (configuration mode).

### Layout Modes
- **Landscape (Active Controller)**: Strict edge-to-edge layout anchored to thumb safe areas. Left and right grip zones span 40% screen width each, sandwiching a central 20% telemetry cluster (polling rate, battery, connection stability).
- **Portrait (Tuning & Remapping)**: A dense single-column layout using fluid 8-column grids for slider modules, response curve editors, and device pairing cards.

### Touch Targets & Safe Zones
- Hardware bezel safe zones enforce a minimum padding of `space-md` (12px) from physical screen edges to prevent gesture navigation conflicts.
- Interactive virtual buttons adhere to minimum touch bounding boxes of 48×48dp, even when visual button caps are smaller.

## Elevation & Depth

This system intentionally eliminates traditional drop shadows in favor of low-contrast technical layering and engineered edge bevels.

### Layer Hierarchy
1. **Base Plate (`#101113`)**: Canvas background. Flat, non-reflective.
2. **Structural Recesses (`#191B1F`)**: Controller grip zones, deadzone wells, and inactive module backplates. Defined by a continuous 1px solid stroke in `#30343A`.
3. **Control Actuators (`#22252A`)**: Virtual D-pads, trigger rockers, and modifier switches. Elevated by contrast differential, bounded by a 1px solid stroke (`#30343A`), and accentuated with an interior highlight (`1px inset rgba(242, 243, 245, 0.04)`).
4. **Engaged State (`#B6F36A` tint)**: When actuated, buttons receive an immediate 1px solid accent outline (`#B6F36A`) with an inner solid tint (`rgba(182, 243, 106, 0.08)`). No outer diffusion or glow passes are permitted.

## Shapes

The design system maintains a tight, engineered corner profile (`6px` to `8px`) across all mechanical containers.

### Curvature Tokens
- **Micro Tags & Axis Readouts**: `rounded-none` or `2px` for crisp, hardware-etched data labels.
- **Standard Controls & Cards**: `rounded` (`4px`–`6px`) for buttons, settings modules, trigger indicators, and menus.
- **Precision Sliders & Trackers**: `rounded-sm` (`4px`) on track wells; thumb handles are squared with minimal edge chamfers.
- **Pills (Status Indicators Only)**: True pill radius (`9999px`) is strictly restricted to compact connection chips (e.g., `BT 5.2 • 2.4ms`).

## Components

### Buttons & Trigger Caps
- **Primary / Actuated Action**: Solid surface `#22252A`, 1px border `#B6F36A`, label in primary text `#F2F3F5` paired with accent detail. On press: zero transition delay, immediate fill shift to `#B6F36A` with `#101113` text.
- **Utility / Inactive Action**: Surface `#191B1F`, border `#30343A`, secondary text `#92979F`.
- **D-Pad & Face Buttons**: Directional cross with `#191B1F` recessed bridge and `#22252A` quadrant plates separated by 2px gutters.

### Status Pills
- Compact height (22px to 26px), inline border `#30343A`, background `#191B1F`.
- Features a discrete 6px circular indicator dot: `#B6F36A` (linked/stable), `#F06464` (dropped/unpaired), `#92979F` (standby).
- Font rendered in `label-sm` (`JetBrains Mono`, uppercase).

### Precision Sliders & Deadzone Modifiers
- **Track**: 4px height, background `#191B1F`, border `#30343A`.
- **Active Range**: Fill color `#B6F36A`.
- **Thumb Handle**: 12×20px vertical rectangular block, surface `#F2F3F5`, rounded corner 2px. No shadow.
- **Telemetry Readout**: Dedicated right-aligned `JetBrains Mono` numerical value updating in real time with fixed width.

### Lists & Keybind Matrix
- Border-separated row items with 1px `#30343A` dividers.
- Left column: Input hardware identifier (e.g., `L2 TRIGGER`) in `label-md`.
- Right column: Re-mappable target (e.g., `AXIS_Z / BTN_7`) wrapped in a `#22252A` chip with a 1px border.

### Checkboxes & Segmented Radios
- **Checkboxes**: 16×16px square, 3px border radius, `#191B1F` fill, `#30343A` border. Checked state renders a crisp solid `#B6F36A` square inset (8×8px), avoiding organic checkmark icons.
- **Segmented Radio Strip**: Contained `#101113` tray with `#22252A` active sliding tabs and 1px border `#30343A`.

### Response Curve Editor (Custom Component)
- 1:1 square viewport framed in `#30343A` with `#191B1F` background.
- 4×4 calibration grid rendered in 1px dashed lines (`#30343A`).
- Spline curve drawn in 2px solid `#B6F36A`. Handle coordinates plotted as 6×6px solid `#F2F3F5` squares.